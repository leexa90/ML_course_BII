# Survival-Analysis-Lifelines
Quick Implementation in python

https://colab.research.google.com/github/leexa90/Survival-Analysis-Lifelines/blob/master/Survival_analysis_ML_course.ipynb

reference : https://towardsdatascience.com/survival-analysis-intuition-implementation-in-python-504fde4fcf8e
